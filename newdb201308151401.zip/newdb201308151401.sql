-- MySQL dump 10.13  Distrib 5.5.30, for Win32 (x86)
--
-- Host: localhost    Database: newdb
-- ------------------------------------------------------
-- Server version	5.5.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `newdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `newdb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `newdb`;

--
-- Table structure for table `customers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `customers` (
  `Cust_ID` int(11) DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Phone_Number` varchar(15) DEFAULT NULL,
  `Street_Address` varchar(30) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Cust_ID`, `Name`, `Phone_Number`, `Street_Address`, `City`, `State`) VALUES (1,'William Dupont','(652)488-9931','801 Oak Street','Eugene','Nebraska'),(2,'Anna Keeney','(716)834-8772','86 East Amherst Street','Buffalo','New York'),(3,'Mariko Randor','(451)842-8933','923 Maple Street','Springfield','Tennessee'),(4,'John Wilson','(758)955-5934','8122 Genessee Street','El Reno','Oklahoma'),(5,'Lynn Seckinger','(552)767-1935','712 Kehr Street','Kent','Washington'),(6,'Richard Tattersall','(455)282-2936','21 South Park Drive','Dallas','Texas'),(7,'Gabriella Sarintia','(819)152-8937','81123 West Seneca Street','Denver','Colorado'),(8,'Lisa Hartwig','(818)852-1937','6652 Sheridan Drive','Sheridan','Wyoming'),(9,'Shirley Jones','(992)488-3931','2831 Main Street','Butte','Montana'),(10,'Bill Sprague','(316)962-0632','1043 Cherry Street','Cheektowaga','New York'),(11,'Greg Doench','(136)692-6023','99 Oak Street','Upper Saddle River','New Jersey'),(12,'Solange Nadeau','(255)767-0935','177 Rue St. Catherine','Montreal','Quebec'),(13,'Heather McGann','(554)282-0936','7192 913 West Park','Buloxie','Mississippi'),(14,'Roy Martin','(918)888-0937','5571 North Olean Avenue','White River','Arkansas'),(15,'Claude Loubier','(857)955-0934','1003 Rue de la Montagne','St. Marguerite de Lingwick','Quebec'),(16,'Dan Woodard','(703)555-1212','2993 Tonawonda Street','Springfield','Missouri'),(17,'Ron Dunlap','(761)678-4251','5579 East Seneca Street','Kansas City','Kansas'),(18,'Keith Frankart','(602)152-6723','88124 Milpidas Lane','Springfield','Maryland'),(19,'Andre Nadeau','(541)842-0933','94219 Rue Florence','St. Marguerite de Lingwick','Quebec'),(20,'Horace Celestin','(914)843-6553','99423 Spruce Street','Ann Arbor','Michigan');

--
-- Table structure for table `student`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  KEY `student_id_idx` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`) VALUES (1,'bhushan'),(4,'Bhushankumar'),(4,'Bhushankumar'),(4,'\'Bhushan\''),(7,'\'Bhushan\''),(7,'Bhushan'),(7,'Bhushan');

--
-- Table structure for table `tbl_employee`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `username`, `password`, `type`) VALUES (24,'Bhushan','Kumar',1),(25,'admin','admin',1);

--
-- Table structure for table `tbl_student`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `tbl_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `fees` int(11) DEFAULT NULL,
  `percentage` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `first_name`, `gender`, `fees`, `percentage`) VALUES (1,'Bhushan','male',78000,78),(6,'Mahesh','male',59000,66),(7,'Vinod','male',4900,53),(13,'Kishan','Male',6100,69.5),(15,'Kumar','male',43330,59.5),(16,'Vijay','Male',41000,87),(17,'Sneha','Female',47000,88),(19,'Neha','Female',78000,78),(20,'Sneha','Female',58000,45),(21,'Poonam','Female',55000,59);

--
-- Table structure for table `uvpce`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `uvpce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uvpce`
--

INSERT INTO `uvpce` (`id`, `first_name`, `last_name`, `salary`) VALUES (1,'Bhushan','Lilapara',70000),(2,'Darshan','Kanani',47000),(4,'Vinod','Khana',77777),(5,' bjj','jhjhj',8989),(6,'vijay','kishan',789789);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-15 14:01:13
